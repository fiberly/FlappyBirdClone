//
//  GameScene.swift
//  FB Clone
//
//  Created by Daniel Barton on 3/4/21.
//
// add a launch screen with start game button

import SpriteKit
import GameplayKit

// allows the control and monitoring of the contact of the different nodes on the screen
class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var birdy = SKSpriteNode();
    
    var backgroundPic = SKSpriteNode();
    
    var pointsLabel = SKLabelNode();
    
    var points = 0;
    
    var timeTaker = Timer();
    
    var GameOver = false;
    
    var GameOverLabel = SKLabelNode();
    
    var startGameButton = UIButton();
    
    // enums are useful ways of grouping different types of objects together, also good for collision detection with SpriteKit
    enum ColliderType: UInt32 {
        
        case Birdy = 1;
        
        case Object = 2;
        
        case spaceBetween = 4;
        
        case None = 8;
        
    }
    
    @objc func pipeCreation() {
         
        
        let pipeAnimation = SKAction.move(by: CGVector(dx: -2 * self.frame.width, dy: 0), duration: TimeInterval(self.frame.width / 100));
        
        let pipeRemoval = SKAction.removeFromParent();

        let pipeMovementAndRemoval = SKAction.sequence([pipeAnimation, pipeRemoval]);
         
         let gapBetween = birdy.size.height * 4;
         
         let pipeMovementCount = arc4random() % UInt32(self.frame.height / 2);
         // random remainder of the pipeMovementCount - the pipePosition
         
         let pipePosition = CGFloat(pipeMovementCount) - self.frame.height / 4;
         
         let pipePhoto = SKTexture(imageNamed: "pipe1.png");
        
         let pipeGreenTop = SKSpriteNode(texture: pipePhoto);
         
         pipeGreenTop.position = CGPoint(x: self.frame.midX + self.frame.width, y: self.frame.midY + pipePhoto.size().height / 2 + gapBetween / 2 + pipePosition);
            
         pipeGreenTop.run(pipeMovementAndRemoval);
        
        // creates a rectangle around the pipe(s)
        pipeGreenTop.physicsBody = SKPhysicsBody(rectangleOf: pipePhoto.size());
        
        pipeGreenTop.physicsBody!.isDynamic = false;
        
        
        // .contactTestBitMask gives an identity to the object being used
        // .categoryBitMask tells SpriteKit which collisions to be notified of
        // .collisionBitMask tells SpriteKit which collision and between which objects SpriteKit's physics engine should control movement post collision
        pipeGreenTop.physicsBody!.contactTestBitMask = ColliderType.Object.rawValue;
       
        pipeGreenTop.physicsBody!.categoryBitMask = ColliderType.Object.rawValue;
       
       // collisionBitMask, makes clear if two objects are able to pass through eachother
        pipeGreenTop.physicsBody!.collisionBitMask = ColliderType.Object.rawValue;
        
        pipeGreenTop.zPosition = -1;
        
         self.addChild(pipeGreenTop);
        
        
        let pipePhoto2 = SKTexture(imageNamed: "pipe2.png");
        
         let pipeGreenBottom = SKSpriteNode(texture: pipePhoto2);
         
         pipeGreenBottom.position = CGPoint(x: self.frame.midX + self.frame.width, y: self.frame.midY - pipePhoto2.size().height / 2 - gapBetween / 2 + pipePosition);
        
         pipeGreenBottom.run(pipeMovementAndRemoval);
         
        // creates a rectangle around the pipe(s)
        pipeGreenBottom.physicsBody = SKPhysicsBody(rectangleOf: pipePhoto2.size());
        
        pipeGreenBottom.physicsBody!.isDynamic = false;
        
        pipeGreenBottom.physicsBody!.contactTestBitMask = ColliderType.Object.rawValue;
        
        pipeGreenBottom.physicsBody!.categoryBitMask = ColliderType.Object.rawValue;
        
        // collisionBitMask, makes clear if two objects are able to pass through eachother
        pipeGreenBottom.physicsBody!.collisionBitMask = ColliderType.Object.rawValue;
        
        pipeGreenBottom.zPosition = -1;
        
         self.addChild(pipeGreenBottom);
        
        
        let spaceBetweens = SKNode();
        
        spaceBetweens.position = CGPoint(x: self.frame.midX + self.frame.width, y: self.frame.midY + pipePosition);
        
        spaceBetweens.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: pipePhoto.size().width, height: gapBetween));
         
        spaceBetweens.physicsBody!.isDynamic = false;
        
        spaceBetweens.run(pipeMovementAndRemoval);
        
        spaceBetweens.physicsBody!.contactTestBitMask = ColliderType.Birdy.rawValue;
        
        spaceBetweens.physicsBody!.categoryBitMask = ColliderType.spaceBetween.rawValue;
        
        spaceBetweens.physicsBody!.collisionBitMask = ColliderType.spaceBetween.rawValue;
        
        self.addChild(spaceBetweens);
        
     }
    
    
    // called when there are contacts between the objects specified in code
    func didBegin(_ contact: SKPhysicsContact) {
        
        
       // self.speed = 0;
        //GameOver = true;
        
        if GameOver == false {
            
        if contact.bodyA.categoryBitMask == ColliderType.spaceBetween.rawValue || contact.bodyB.categoryBitMask == ColliderType.spaceBetween.rawValue {
            
            print("you passed through a pipe!");
            
            points += 1;
            
            pointsLabel.text = String(points);
            
        } else {
            
            print("object contacted");

            self.speed = 0;
            
            GameOver = true;
            
            timeTaker.invalidate();
            
            GameOverLabel.fontName = "Times New Roman";
            
            GameOverLabel.fontSize  = 30;
            
            GameOverLabel.text = "Your bird had a problem with flight, Tap again to restart?";
            
            GameOverLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY);
            
            self.addChild(GameOverLabel);
            
        }
        
    }
}
    
    // similar to view did load
    override func didMove(to view: SKView) {
        
        // setting the contactDelegate as the view controller or the game scene
        self.physicsWorld.contactDelegate = self;
        
        gameSetup();
        
        }
    
    func gameSetup() {
        
        // the time interval below, is apparently there to help with larger screens?
        timeTaker = Timer.scheduledTimer(timeInterval: 4, target: self, selector: #selector(self.pipeCreation), userInfo: nil, repeats: true);
        
        var a: CGFloat = 0;
        
        let backgroundImage = SKTexture(imageNamed: "bg.png");
        
        let backgroundImageMove = SKAction.move(by: CGVector(dx: -backgroundImage.size().width, dy: 0), duration: 7);
        
        let backgroundMove = SKAction.move(by: CGVector(dx: backgroundImage.size().width, dy: 0), duration: 0);
        
        let animateBackgroundForGood = SKAction.repeatForever(SKAction.sequence([backgroundImageMove, backgroundMove]));
        
        while a < 3 {
        // positions center of backgroundImage aligned with the left of the screen, aligns to the right edge of the first second while loop background, third run through would be aligned to the right edge of the second while loop
            
            backgroundPic = SKSpriteNode(texture: backgroundImage);
            
            backgroundPic.position = CGPoint(x: backgroundImage.size().width * a, y: self.frame.midY);
            
            backgroundPic.size.height = self.frame.height;
            
            backgroundPic.run(animateBackgroundForGood);
            
            backgroundPic.zPosition = -2;
            
            self.addChild(backgroundPic);
            
            a += 1;
            
        }
        
        let textureOfBirdy = SKTexture(imageNamed: "flappy1.png");
        
        let textureOfBirdy2 = SKTexture(imageNamed: "flappy2.png");
        
        let animation = SKAction.animate(with: [textureOfBirdy, textureOfBirdy2], timePerFrame: 0.2);
        
        let makeAnimateForever = SKAction.repeatForever(animation);
        
        birdy = SKSpriteNode(texture: textureOfBirdy);
        
        birdy.position = CGPoint(x: self.frame.midX, y: self.frame.midY);
        
        birdy.run(makeAnimateForever);
        
        birdy.physicsBody = SKPhysicsBody(circleOfRadius: textureOfBirdy.size().height / 2);
        
        birdy.physicsBody!.isDynamic = false;
        
        birdy.physicsBody!.contactTestBitMask = ColliderType.Object.rawValue;
        
        birdy.physicsBody!.categoryBitMask = ColliderType.Birdy.rawValue;
        
        // collisionBitMask, makes clear if two objects are able to pass through eachother
        birdy.physicsBody!.collisionBitMask = ColliderType.Birdy.rawValue;
        
        self.addChild(birdy);
        
        
        let groundDeath = SKNode();
        
        groundDeath.position = CGPoint(x: self.frame.midX, y: -self.frame.height / 2);
        
        groundDeath.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: self.frame.width, height: 1));
       
        // ground does not move below this comment
        groundDeath.physicsBody!.isDynamic = false;
        
      // birdy.physicsBody!.contactTestBitMask = ColliderType.Object.rawValue;
        
        // birdy.physicsBody!.categoryBitMask = ColliderType.Object.rawValue;
        
        birdy.physicsBody!.collisionBitMask = ColliderType.Object.rawValue;
        
        groundDeath.physicsBody!.contactTestBitMask = ColliderType.Object.rawValue;
        
        groundDeath.physicsBody!.categoryBitMask = ColliderType.Object.rawValue;
        
        groundDeath.physicsBody!.collisionBitMask = ColliderType.Object.rawValue;
        
        self.addChild(groundDeath);
        
        
        pointsLabel.fontName = "Times New Roman";
        
        pointsLabel.fontSize = 70;
        
        pointsLabel.text = "0";
            
        pointsLabel.position = CGPoint(x: self.frame.midX, y: self.frame.height / 2 - 70);
        
        self.addChild(pointsLabel);
    
}
    
    // when user touches screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if GameOver == false {
            
        // allows the bird to be pulled down by gravity
        birdy.physicsBody!.isDynamic = true;
        
        birdy.physicsBody!.velocity = CGVector(dx: 0, dy: 0);
        
        birdy.physicsBody!.applyImpulse(CGVector(dx: 0, dy: 50));
            
        } else {
            
            GameOver = false;
            
            points = 0;
            
            self.speed = 1;
            
            self.removeAllChildren();
            
            gameSetup();
            
        }
    }
        
  // called many times a second, letting us check for things such as collisons, move game items, do things multiple times without having to reset the view?
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }

}
